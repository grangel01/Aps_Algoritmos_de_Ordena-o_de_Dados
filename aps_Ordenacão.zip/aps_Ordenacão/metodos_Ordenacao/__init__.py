# ----- importa as funções necessárias para que os métodos de ordenação sejam excecutados -----

from .SelectionSort import selectionSort
from .QuickSort import quickSort
from .BubbleSort import bubble_sort_pilhas