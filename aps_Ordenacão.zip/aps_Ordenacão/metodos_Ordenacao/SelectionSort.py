
#FUNÇÃO PARA ORDENAR LISTA COM SELECTION SORT
comparacoes=0

def selectionSort(listaDesordenada): 
    global comparacoes
    contador=0
    total = len(listaDesordenada)

    for item in range(total-1):
        listaOrdenada= []
        indiceMin=item

        for aux in range(item, total):
            if listaDesordenada[aux]< listaDesordenada[indiceMin]:
                indiceMin=aux
        
            if listaDesordenada[item] > listaDesordenada [indiceMin]:
                auxArmazen = listaDesordenada[item]
                contador += 1
                listaDesordenada[item]=listaDesordenada[indiceMin]
                listaDesordenada[indiceMin]=auxArmazen
            listaOrdenada = listaDesordenada
    
    
    print (listaOrdenada, "\nContador: ",contador)

