class Pilha:
    def __init__(self):
        self.itens = []

    def empilhar(self, item):
        self.itens.append(item)

    def desempilhar(self):
        if not self.esta_vazia():
            return self.itens.pop()
        else:
            return None

    def esta_vazia(self):
        return len(self.itens) == 0

    def topo(self):
        if not self.esta_vazia():
            return self.itens[-1]
        else:
            return None

    def tamanho(self):
        return len(self.itens)


def bubble_sort_pilhas(lista):
    pilha_ordenada = Pilha()
    pilha_auxiliar = Pilha()
    contador= 0
    for item in lista:
        pilha_ordenada.empilhar(item)
    for i in range(len(lista)):
        trocou = False
        while not pilha_ordenada.esta_vazia():
            item = pilha_ordenada.desempilhar()
            if not pilha_auxiliar.esta_vazia() and item > pilha_auxiliar.topo():
                
                pilha_ordenada.empilhar(pilha_auxiliar.desempilhar())
                pilha_ordenada.empilhar(item)
                trocou = True
            else:
                pilha_auxiliar.empilhar(item)
            contador+= 1
        while not pilha_auxiliar.esta_vazia():
            pilha_ordenada.empilhar(pilha_auxiliar.desempilhar())
    
        if not trocou:
            break  

    lista_ordenada = []
    while not pilha_ordenada.esta_vazia():
        lista_ordenada.insert(0, pilha_ordenada.desempilhar())
    
    print (lista_ordenada, "\nContador: ",contador)


'''import random
lista_desordenada = random.sample(range(1, 100001), 10)
lista_ordenada = bubble_sort_pilhas(lista_desordenada)
print(lista_desordenada)
print(bubble_sort_pilhas(lista_desordenada)) 
''' 