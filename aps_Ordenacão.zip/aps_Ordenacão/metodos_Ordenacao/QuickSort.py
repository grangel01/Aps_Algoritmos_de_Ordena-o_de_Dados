import random
import time

comparacoes = 0

def quickSort(lista):
    global comparacoes
    if len(lista) <= 1:
        return lista
    
    pivo = lista[len(lista) // 2]
    
    menores = []
    iguais = []
    maiores = []

    for elemento in lista:
        if elemento < pivo:
            menores.append(elemento)
        elif elemento == pivo:
            iguais.append(elemento)
        else:
            maiores.append(elemento)
    
    comparacoes += len(lista) - 1 
    
    return quickSort(menores) + iguais + quickSort(maiores) 
    

'''def main():
    quantidade = int(input("Quantos números você deseja na lista? "))

    listaDesordenada = []
    for _ in range(quantidade):
        numero = random.randint(0, 15000)
        listaDesordenada.append(numero)
    print("Lista original:", listaDesordenada)

    global comparacoes
    comparacoes = 0 
    inicio = time.perf_counter()
    listaOrdenada = quickSort(listaDesordenada)
    fim = time.perf_counter()

    print("Lista ordenada:", listaOrdenada)
    print("Número de comparações:", comparacoes)
    print("Tempo de execução: {:.6f} segundos".format(fim - inicio))

if __name__ == "__main__":
    main()'''