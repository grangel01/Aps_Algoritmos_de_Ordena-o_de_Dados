'''import metodos_Ordenacao
import random
import time 


quantidade = int(input("Digite quantos números deseja ordenar: "))
lista= []

for _ in range(quantidade):
    numero = random.randint(0, 15000)
    lista.append(numero)

print ('\n',lista)
lista1 = lista[:]
lista2 = lista[:]
print(f'\n\n\nINICIO\n\n\n')

inicio = time.perf_counter()
metodos_Ordenacao.selectionSort(lista)
fim=time.perf_counter()
print("\nTempo de execução SelectionSort: {:.6f} segundos\n".format(fim - inicio))


inicio= time.perf_counter()
global comparacoes
comparacoes = 0 
print(metodos_Ordenacao.quickSort(lista1))
fim= time.perf_counter()
print("\nTempo de execução QuickSort: {:.6f} segundos\n".format(fim - inicio))



inicio = time.perf_counter()
metodos_Ordenacao.bubble_sort_pilhas(lista2)
fim=time.perf_counter()
print("\nTempo de execução BublleSort: {:.6f} segundos\n".format(fim - inicio))     '''
